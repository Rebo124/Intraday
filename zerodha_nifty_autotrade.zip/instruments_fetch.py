
"""Fetch instrument dump via Kite REST and filter NIFTY option contracts.
Requires API_KEY and ACCESS_TOKEN (set in env or config)."""
import os, json, argparse
from kiteconnect import KiteConnect

def fetch_instruments(api_key, access_token, out_file='instruments.csv'):
    kite = KiteConnect(api_key=api_key)
    kite.set_access_token(access_token)
    print('Downloading instruments dump (may take a while)...')
    # KiteConnect has instruments() method to dump CSV-like text
    instruments = kite.instruments()
    # instruments is a list of dicts with keys like 'exchange','tradingsymbol','instrument_token'
    # Save to JSON for easier filtering
    with open(out_file, 'w') as f:
        json.dump(instruments, f, indent=2)
    print('Saved to', out_file)
    return instruments

def filter_nifty_options(instruments):
    # Filter logic: exchange NFO and tradingsymbol starts with NIFTY and contains CE or PE
    results = [i for i in instruments if i.get('exchange') in ['NFO'] and i.get('tradingsymbol','').startswith('NIFTY') and ('CE' in i.get('tradingsymbol','') or 'PE' in i.get('tradingsymbol',''))]
    return results

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--api_key', default=os.environ.get('API_KEY'))
    parser.add_argument('--access_token', default=os.environ.get('ACCESS_TOKEN'))
    parser.add_argument('--out', default='nifty_instruments.json')
    args = parser.parse_args()
    if not args.api_key or not args.access_token:
        print('Provide API_KEY and ACCESS_TOKEN via args or environment variables.')
    else:
        instruments = fetch_instruments(args.api_key, args.access_token, out_file=args.out)
        filtered = filter_nifty_options(instruments)
        print('Found', len(filtered), 'NIFTY option contracts. Sample:')
        print(filtered[:10])
