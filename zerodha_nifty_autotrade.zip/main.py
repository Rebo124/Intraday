
import os, time, logging, json
from kiteconnect import KiteConnect, KiteTicker
from dotenv import load_dotenv
from strategy import SMA_Momentum_Strategy
from utils import place_order

load_dotenv()  # loads .env

API_KEY = os.getenv('API_KEY')
ACCESS_TOKEN = os.getenv('ACCESS_TOKEN')

# load config
with open('config.json') as f:
    cfg = json.load(f)

LOG_LEVEL = getattr(logging, cfg.get('log_level','INFO'))
logging.basicConfig(level=LOG_LEVEL, format='%(asctime)s %(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

DRY_RUN = cfg.get('dry_run', True)
QTY = cfg.get('quantity',1)
PRODUCT = cfg.get('product','MIS')
ORDER_TYPE = cfg.get('order_type','MARKET')
TRADINGSYMBOLS = cfg.get('tradingsymbols', [])

kite = KiteConnect(api_key=API_KEY)
kite.set_access_token(ACCESS_TOKEN)

strategy_cfg = cfg.get('strategy',{})
strategy = SMA_Momentum_Strategy(fast=strategy_cfg.get('sma_fast',3), slow=strategy_cfg.get('sma_slow',8), momentum_thr=strategy_cfg.get('momentum_threshold',1.0))

kws = KiteTicker(API_KEY, ACCESS_TOKEN)

def on_ticks(ws, ticks):
    # ticks: list of dicts with keys including 'tradingsymbol' and 'last_price' or 'last_traded_price'
    for t in ticks:
        tradingsymbol = t.get('tradingsymbol') or t.get('instrument_token')
        ltp = t.get('last_price') or t.get('last_traded_price') or t.get('ltp') or t.get('last_price')
        if not tradingsymbol or ltp is None:
            continue
        decision = strategy.on_tick(tradingsymbol, ltp)
        if decision and decision.get('action'):
            action = decision['action']
            logger.info("Strategy decision for %s: %s at %.2f", tradingsymbol, action, float(ltp))
            place_order(kite, tradingsymbol=tradingsymbol, transaction_type=action, quantity=QTY, product=PRODUCT, order_type=ORDER_TYPE, dry_run=DRY_RUN, exchange='NFO')

def on_connect(ws, response):
    logger.info("WebSocket connected. Subscribing to tradingsymbols: %s", TRADINGSYMBOLS)
    # KiteTicker subscribe expects instrument tokens; here we try to subscribe by mapping via instruments if provided.
    # For convenience, user can provide instrument tokens in config['instruments']
    instruments = cfg.get('instruments', [])
    if instruments:
        ws.subscribe(instruments)
        ws.set_mode(ws.MODE_FULL, instruments)
    else:
        logger.warning("No instrument tokens provided in config.json. Use instruments_fetch.py to get tokens.")

def on_close(ws, code, reason):
    logger.warning("WebSocket closed: %s %s", code, reason)

def on_error(ws, code, reason):
    logger.error("WebSocket error: %s %s", code, reason)

kws.on_ticks = on_ticks
kws.on_connect = on_connect
kws.on_close = on_close
kws.on_error = on_error

if __name__ == '__main__':
    try:
        kws.connect(threaded=True)
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("Exiting on user interrupt")
        kws.close()
    except Exception as e:
        logger.exception("Fatal: %s", e)
