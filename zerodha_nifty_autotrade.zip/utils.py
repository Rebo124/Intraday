
import logging
from kiteconnect import KiteConnect

logger = logging.getLogger(__name__)

def place_order(kite: KiteConnect, tradingsymbol: str, transaction_type: str, quantity: int, product='MIS', order_type='MARKET', dry_run=True, exchange='NFO'):
    '''Place order wrapper. If dry_run True, only logs.'''
    try:
        if dry_run:
            logger.info("DRY-RUN: Order %s %s qty=%s product=%s order_type=%s", transaction_type, tradingsymbol, quantity, product, order_type)
            return None
        order_id = kite.place_order(
            variety=kite.VARIETY_REGULAR,
            exchange=exchange,
            tradingsymbol=tradingsymbol,
            transaction_type=transaction_type,
            quantity=quantity,
            product=product,
            order_type=order_type
        )
        logger.info("Order placed: %s", order_id)
        return order_id
    except Exception as e:
        logger.exception("Order error: %s", e)
        return None
