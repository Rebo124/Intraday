
# Example SMA crossover + momentum strategy for NIFTY options
from collections import deque
import numpy as np

class SMA_Momentum_Strategy:
    def __init__(self, fast=3, slow=8, momentum_thr=1.0):
        self.fast = fast
        self.slow = slow
        self.momentum_thr = momentum_thr
        self.prices = {}  # tradingsymbol -> deque of recent LTPs

    def _update(self, tradingsymbol, ltp):
        dq = self.prices.setdefault(tradingsymbol, deque(maxlen=self.slow))
        dq.append(float(ltp))
        return list(dq)

    def on_tick(self, tradingsymbol, ltp):
        prices = self._update(tradingsymbol, ltp)
        if len(prices) < self.slow:
            return None  # not enough data
        fast_sma = np.mean(prices[-self.fast:])
        slow_sma = np.mean(prices[-self.slow:])
        momentum = prices[-1] - prices[-2]
        if fast_sma > slow_sma and momentum >= self.momentum_thr:
            return {'action': 'BUY', 'ltp': ltp}
        elif fast_sma < slow_sma and momentum <= -self.momentum_thr:
            return {'action': 'SELL', 'ltp': ltp}
        return None
