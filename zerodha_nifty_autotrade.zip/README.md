# Zerodha (Kite Connect) NIFTY F&O Intraday Auto-Trader (Example)

**Purpose:** Educational example of an intraday bot that listens to live market ticks (KiteTicker WebSocket) and can place BUY / SELL orders for **NIFTY F&O** contracts via Zerodha's Kite Connect API.

**Important:** This is example code for educational purposes only. It defaults to **DRY-RUN** (no live orders). Use extreme caution when enabling live orders.

## What's included
- `main.py` — main runner: connects to Kite WebSocket, applies strategy, and places orders (if `DRY_RUN=false`).
- `strategy.py` — example strategy focused on NIFTY options (simple SMA crossover on ticks + momentum filter).
- `instruments_fetch.py` — helper to download and filter instrument tokens (requires REST API).
- `utils.py` — helpers for tradingsymbol construction and order helpers.
- `config.json` — configuration template (also supports environment variables).
- `.env.template` — template for secrets (API_KEY, API_SECRET, ACCESS_TOKEN).
- `Dockerfile` — optional Docker image to run the bot.
- `requirements.txt` — Python dependencies.
- `.gitignore` — recommended ignores.
- `LICENSE` — MIT.

## High-level flow
1. Populate `.env` with your `API_KEY`, `API_SECRET`, and `ACCESS_TOKEN` (or use login flow).
2. Use `instruments_fetch.py` to get the required instrument token(s) for the desired NIFTY expiry/strike/CE-PE.
3. Edit `config.json` to list `tradingsymbols` or instrument tokens and set `"dry_run": true` for testing.
4. Run `python main.py`. Bot connects to WebSocket, applies the strategy, and logs actions. If `dry_run` is false, it will place orders via Kite REST API.

## Quick start (GitHub-ready)
1. Create a private GitHub repo and push these files (don't commit your `.env`).
2. Locally: `python -m venv venv && source venv/bin/activate` (Linux/mac) or `venv\Scripts\activate` (Windows).
3. `pip install -r requirements.txt`
4. Copy `.env.template` to `.env` and fill secrets.
5. (Optional) `python instruments_fetch.py --exchange NFO --symbol NIFTY` to list available NIFTY option tradingsymbols (requires valid credentials).
6. Update `config.json` with the exact `tradingsymbols` you want (example shown).
7. Run: `python main.py`

## Safety & best practices
- **DRY-RUN by default**. Keep `dry_run` true while testing.
- Use small position sizes; add risk-management layers (max_drawdown, max_daily_trades).
- Respect Kite Connect rate limits and NSE/NFO market rules. Abide by Zerodha's ToS.
- Use logging, alerts, and monitoring. Deploy to a reliable host and supervise initial runs.

## Notes about NIFTY F&O tradingsymbols
- NIFTY options tradingsymbols follow pattern like `NIFTY31OCTXXXXX0CE` (varies by expiry formatting).
- Use `instruments_fetch.py` to search and filter the official instrument dump to find exact tradingsymbol & instrument_token for order placement.

## Disclaimer
This repository is **not financial advice**. Live trading carries financial risk. Test thoroughly on paper or small sizes.

